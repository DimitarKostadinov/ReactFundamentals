Project Starter Kit for React. Features:
- Routing
- User authentication: Register/Login/Logout
